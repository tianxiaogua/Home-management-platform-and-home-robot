#encoding:utf-8
import snowboydecoder
import sys
import signal

#interrupted = False

#def signal_handler(signal, frame):
#    global interrupted
#    interrupted = True

class mainsnow():
    
    def __init__(self):
        self.interrupted = False
        self.mainCheck()
        
    def interrupt_callback(self):
        #global interrupted
        return self.interrupted

    def mainCheck(self):
        print("begin to check:")
        model = "小花.pmdl"#sys.argv[1]
        # capture SIGINT signal, e.g., Ctrl+C
        #signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGINT, True)

        detector = snowboydecoder.HotwordDetector(model, sensitivity=0.5)
        print('Listening... Press Ctrl+C to exit')
        # main loop
        detector.start( detected_callback = snowboydecoder.play_audio_file,
                        interrupt_check = self.interrupt_callback,
                        sleep_time=0.03)
        detector.terminate()
        
"""
"""
if __name__ == '__main__':
    while True:
        a = mainsnow()
        #a.mainCheck()#Stop and waiting if True,continue.
        print("识别成功")
